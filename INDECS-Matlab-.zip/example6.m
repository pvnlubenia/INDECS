% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 6                                                                %
%                                                                             %
%                                                                             %
% This is Example 13 in Hernandez and De la Cruz (2021): Generalized mass     %
%    action model of purine metabolism in man                                 %
%                                                                             %
% RESULT: The independent decomposition of the network of 42 reactions        %
%            contains 2 partitions.                                           %
%                                                                             %
% Reference: Hernandez, B.S. and De la Cruz, R.J.L. (2021). Independent       %
%    decompositions of chemical reaction networks. Bulletin of Mathematical   %
%    Biology, 83(76), 1–23. doi:10.1007/s11538-021-00906-3                    %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 13';
model.species = { }; % do not fill out; will be filled automatically by 'indep_decomp'
model.reaction(1) = struct('id', 'X1+X17+X4+X8+X18->2X1+X4+X8+X18', 'reactant', struct('species', {'X1', 'X17', 'X4', 'X8', 'X18'}, 'stoichiometry', {1, 1, 1, 1, 1}), 'product', struct('species', {'X1', 'X4', 'X8', 'X18'}, 'stoichiometry', {2, 1, 1, 1}), 'reversible', false);
model.reaction(2) = struct('id', 'X1->0', 'reactant', struct('species', {'X1'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(3) = struct('id', 'X1+X2+X4+X8+X18->2X2+X4+X8+X18', 'reactant', struct('species', {'X1', 'X2', 'X4', 'X8', 'X18'}, 'stoichiometry', {1, 1, 1, 1, 1}), 'product', struct('species', {'X2', 'X4', 'X8', 'X18'}, 'stoichiometry', {2, 1, 1, 1}), 'reversible', false);
model.reaction(4) = struct('id', 'X1+X4+X6->2X4+X6', 'reactant', struct('species', {'X1', 'X4', 'X6'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X4', 'X6'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(5) = struct('id', 'X1+X4+X6->2X4+X1', 'reactant', struct('species', {'X1', 'X4', 'X6'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X4', 'X1'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(6) = struct('id', 'X1+X2+X13->2X2+X13', 'reactant', struct('species', {'X1', 'X2', 'X13'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X2', 'X13'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(7) = struct('id', 'X1+X2+X13->X1+2X2', 'reactant', struct('species', {'X1', 'X2', 'X13'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X1', 'X2'}, 'stoichiometry', {1, 2}), 'reversible', false);
model.reaction(8) = struct('id', 'X1+X8+X15->2X8+X15', 'reactant', struct('species', {'X1', 'X8', 'X15'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X8', 'X15'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(9) = struct('id', 'X1+X8+X15->2X8+X1', 'reactant', struct('species', {'X1', 'X8', 'X15'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X8', 'X1'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(10) = struct('id', 'X2+X4+X8+X18->X3+X4+X8+X18', 'reactant', struct('species', {'X2', 'X4', 'X8', 'X18'}, 'stoichiometry', {1, 1, 1, 1}), 'product', struct('species', {'X3', 'X4', 'X8', 'X18'}, 'stoichiometry', {1, 1, 1, 1}), 'reversible', false);
model.reaction(11) = struct('id', 'X2+X7+X8->2X7+X8', 'reactant', struct('species', {'X2', 'X7', 'X8'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X7', 'X8'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(12) = struct('id', 'X2+X18->X13+X18', 'reactant', struct('species', {'X2', 'X18'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X13', 'X18'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(13) = struct('id', 'X4+X8+X18->X2+X8+X18', 'reactant', struct('species', {'X4', 'X8', 'X18'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X2', 'X8', 'X18'}, 'stoichiometry', {1, 1, 1}), 'reversible', false);
model.reaction(14) = struct('id', 'X2+X4+X8+X7->2X2+X4+X7', 'reactant', struct('species', {'X2', 'X4', 'X8', 'X7'}, 'stoichiometry', {1, 1, 1, 1}), 'product', struct('species', {'X2', 'X4', 'X7'}, 'stoichiometry', {2, 1, 1}), 'reversible', false);
model.reaction(15) = struct('id', 'X3+X4->2X4', 'reactant', struct('species', {'X3', 'X4'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X4'}, 'stoichiometry', {2}), 'reversible', false);
model.reaction(16) = struct('id', 'X11->X4', 'reactant', struct('species', {'X11'}, 'stoichiometry', {1}), 'product', struct('species', {'X4'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(17) = struct('id', 'X5->X4', 'reactant', struct('species', {'X5'}, 'stoichiometry', {1}), 'product', struct('species', {'X4'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(18) = struct('id', 'X4+X5->2X5', 'reactant', struct('species', {'X4', 'X5'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X5'}, 'stoichiometry', {2}), 'reversible', false);
model.reaction(19) = struct('id', 'X4+X9+X10->2X9+X10', 'reactant', struct('species', {'X4', 'X9', 'X10'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X9', 'X10'}, 'stoichiometry', {2, 1}), 'reversible', false);
model.reaction(20) = struct('id', 'X4->X13', 'reactant', struct('species', {'X4'}, 'stoichiometry', {1}), 'product', struct('species', {'X13'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(21) = struct('id', 'X4+X8->X8+X11', 'reactant', struct('species', {'X4', 'X8'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X8', 'X11'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(22) = struct('id', 'X4+X8->X4+X11', 'reactant', struct('species', {'X4', 'X8'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X4', 'X11'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(23) = struct('id', 'X5->X6', 'reactant', struct('species', {'X5'}, 'stoichiometry', {1}), 'product', struct('species', {'X6'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(24) = struct('id', 'X6->0', 'reactant', struct('species', {'X6'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(25) = struct('id', 'X4+X7->X4+X8', 'reactant', struct('species', {'X4', 'X7'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X4', 'X8'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(26) = struct('id', 'X11->X8', 'reactant', struct('species', {'X11'}, 'stoichiometry', {1}), 'product', struct('species', {'X8'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(27) = struct('id', 'X8+X18->X15+X18', 'reactant', struct('species', {'X8', 'X18'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X15', 'X18'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(28) = struct('id', 'X8+X9+X10->X9+2X10', 'reactant', struct('species', {'X8', 'X9', 'X10'}, 'stoichiometry', {1, 1, 1}), 'product', struct('species', {'X9', 'X10'}, 'stoichiometry', {1, 2}), 'reversible', false);
model.reaction(29) = struct('id', 'X12->X9', 'reactant', struct('species', {'X12'}, 'stoichiometry', {1}), 'product', struct('species', {'X9'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(30) = struct('id', 'X9+X10->X12+X10', 'reactant', struct('species', {'X9', 'X10'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X12', 'X10'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(31) = struct('id', 'X9+X10->X12+X9', 'reactant', struct('species', {'X9', 'X10'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X12', 'X9'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(32) = struct('id', 'X9->X13', 'reactant', struct('species', {'X9'}, 'stoichiometry', {1}), 'product', struct('species', {'X13'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(33) = struct('id', 'X12->X10', 'reactant', struct('species', {'X12'}, 'stoichiometry', {1}), 'product', struct('species', {'X10'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(34) = struct('id', 'X10->X15', 'reactant', struct('species', {'X10'}, 'stoichiometry', {1}), 'product', struct('species', {'X15'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(35) = struct('id', 'X13->X14', 'reactant', struct('species', {'X13'}, 'stoichiometry', {1}), 'product', struct('species', {'X14'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(36) = struct('id', 'X13->0', 'reactant', struct('species', {'X13'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(37) = struct('id', 'X15->X14', 'reactant', struct('species', {'X15'}, 'stoichiometry', {1}), 'product', struct('species', {'X14'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(38) = struct('id', 'X14->0', 'reactant', struct('species', {'X14'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(39) = struct('id', 'X14->X16', 'reactant', struct('species', {'X14'}, 'stoichiometry', {1}), 'product', struct('species', {'X16'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(40) = struct('id', 'X16->0', 'reactant', struct('species', {'X16'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(41) = struct('id', '0->X17', 'reactant', struct('species', { }, 'stoichiometry', { }), 'product', struct('species', {'X17'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(42) = struct('id', '0->X18', 'reactant', struct('species', { }, 'stoichiometry', { }), 'product', struct('species', {'X18'}, 'stoichiometry', {1}), 'reversible', false);

% Generate the independent decomposition
[model, R, G, P] = indep_decomp(model);