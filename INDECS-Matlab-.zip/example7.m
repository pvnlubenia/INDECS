% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 7                                                              %
%                                                                           %
%                                                                           %
% This is Example 14 in Hernandez and De la Cruz (2021): A reaction network %
%    governed by mass action kinetics                                       %
%                                                                           %
% RESULT: The independent decomposition of the network of 4 reactions       %
%    contains 2 partitions.                                                 %
%                                                                           %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                %
%    https://doi.org/10.1007/s11538-021-00906-3                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 7';
model = addReaction(model, 'X1+X2->X3', ...                  % just a visual guide on how the reaction looks like
                           {'X1', 'X2'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'X3'}, {1}, [ ], ...             % product species, stoichiometry, "kinetic order" (if reversible)
                           false);                           % reversible or not
model = addReaction(model, 'X3+X4->X4+X1+X2', ...
                           {'X3', 'X4'}, {1, 1}, [1, 1], ...
                           {'X4', 'X1', 'X2'}, {1, 1, 1}, [ ], ...
                           false);
model = addReaction(model, 'X1+X3->X4+X1+X3', ...
                           {'X1', 'X3'}, {1, 1}, [1, 1], ...
                           {'X4', 'X1', 'X3'}, {1, 1, 1}, [ ], ...
                           false);
model = addReaction(model, 'X4+2X2->2X2', ...
                           {'X4', 'X2'}, {1, 2}, [1, 2], ...
                           {'X2'}, {2}, [ ], ...
                           false);

% Generate the independent decomposition
[model, R, G, P] = indepDecomp(model);