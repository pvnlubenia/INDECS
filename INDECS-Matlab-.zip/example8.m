% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 8                                                              %
%                                                                           %
%                                                                           %
% This is Figure 7 in Yu and Craciun (2018)                                 %
%                                                                           %
% RESULT: The network of 9 reactions has no nontrivial independent          %
%    decomposition.                                                         %
%                                                                           %
% Reference: Yu P, Craciun G (2018) Mathematical analysis of chemical       %
%    reaction systems. Isr J Chem 58:1-10.                                  %
%    https://doi.org/10.1002/ijch.201800003                                 %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 8';
model = addReaction(model, 'X1+X2<->X3', ...                 % just a visual guide on how the reaction looks like
                           {'X1', 'X2'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'X3'}, {1}, [1], ...             % product species, stoichiometry, "kinetic order" (if reversible)
                           true);                            % reversible or not
model = addReaction(model, 'X1->2X2', ...
                           {'X1'}, {1}, [1], ...
                           {'X2'}, {2}, [ ], ...
                           false);
model = addReaction(model, 'X1<->0', ...
                           {'X1'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           true);
model = addReaction(model, 'X2<->0', ...
                           {'X2'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           true);
model = addReaction(model, 'X3<->0', ...
                           {'X3'}, {1}, [1], ...
                           { }, { }, [ ], ...
                           true);

% Generate the independent decomposition
[model, R, G, P] = indepDecomp(model);