% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 3                                                                %
%                                                                             %
%                                                                             %
% This is Example 10 in Hernandez and De la Cruz (2021): Baccam influenza     %
%    virus model                                                              %
%                                                                             %
% RESULT: The independent decomposition of the network of 4 reactions         %
%            contains 3 partitions.                                           %
%                                                                             %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of   %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                  %
%    https://doi.org/10.1007/s11538-021-00906-3                               %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 3';
model.species = { }; % do not fill out; will be filled automatically by 'indep_decomp'
model.reaction(1) = struct('id', 'T+V->I+V', 'reactant', struct('species', {'T', 'V'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'I', 'V'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(2) = struct('id', 'I->0', 'reactant', struct('species', {'I'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(3) = struct('id', 'I->I+V', 'reactant', struct('species', {'I'}, 'stoichiometry', {1}), 'product', struct('species', {'I', 'V'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(4) = struct('id', 'V->0', 'reactant', struct('species', {'V'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);

% Generate the independent decomposition
[model, R, G, P] = indep_decomp(model);