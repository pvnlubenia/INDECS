% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 3                                                              %
%                                                                           %
%                                                                           %
% This is Example 10 in Hernandez and De la Cruz (2021): Baccam influenza   %
%    virus model                                                            %
%                                                                           %
% RESULT: The independent decomposition of the network of 4 reactions       %
%    contains 3 partitions.                                                 %
%                                                                           %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                %
%    https://doi.org/10.1007/s11538-021-00906-3                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 3';
model = addReaction(model, 'T+V->I+V', ...                 % just a visual guide on how the reaction looks like
                           {'T', 'V'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'I', 'V'}, {1, 1}, [ ], ...    % product species, stoichiometry, "kinetic order" (if reversible)
                           false);                         % reversible or not
model = addReaction(model, 'I->0', ...
                           {'I'}, {1}, [1], ...
                           {}, {}, [ ], ...
                           false);
model = addReaction(model, 'I->I+V', ...
                           {'I'}, {1}, [1], ...
                           {'I', 'V'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'V->0', ...
                           {'V'}, {1}, [1], ...
                           {}, {}, [ ], ...
                           false);

% Generate the independent decomposition
[model, R, G, P] = indepDecomp(model);