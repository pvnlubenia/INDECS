% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 4                                                              %
%                                                                           %
%                                                                           %
% This is Example 11 in Hernandez and De la Cruz (2021): Baccam influenza   %
%    virus model with delayed virus production                              %
%                                                                           %
% RESULT: The independent decomposition of the network of 5 reactions       %
%    contains 4 partitions.                                                 %
%                                                                           %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                %
%    https://doi.org/10.1007/s11538-021-00906-3                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 4';
model = addReaction(model, 'T+V->I1+V', ...                % just a visual guide on how the reaction looks like
                           {'T', 'V'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'I1', 'V'}, {1, 1}, [ ], ...   % product species, stoichiometry, "kinetic order" (if reversible)
                           false);                         % reversible or not
model = addReaction(model, 'I1->I2', ...
                           {'I1'}, {1}, [1], ...
                           {'I2'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'I2->0', ...
                           {'I2'}, {1}, [1], ...
                           {}, {}, [ ], ...
                           false);
model = addReaction(model, 'I2->I2+V', ...
                           {'I2'}, {1}, [1], ...
                           {'I2', 'V'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'V->0', ...
                           {'V'}, {1}, [1], ...
                           {}, {}, [ ], ...
                           false);

% Generate the independent decomposition
[model, R, G, P] = indepDecomp(model);