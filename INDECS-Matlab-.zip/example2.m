% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 2                                                                %
%                                                                             %
%                                                                             %
% This is Example 9 in Hernandez and De la Cruz (2021): A metabolic network   %
%    with one positive feedforward and a negative feedback                    %
%                                                                             %
% RESULT: The network of 6 reactions has no nontrivial independent            %
%            decomposition.                                                   %
%                                                                             %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of   %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                  %
%    https://doi.org/10.1007/s11538-021-00906-3                               %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2';
model.species = { }; % do not fill out; will be filled automatically by 'indep_decomp'
model.reaction(1) = struct('id', '0->X1', 'reactant', struct('species', { }, 'stoichiometry', { }), 'product', struct('species', {'X1'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(2) = struct('id', 'X1+X3->X3+X2', 'reactant', struct('species', {'X1', 'X3'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X3', 'X2'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(3) = struct('id', 'X2->X3', 'reactant', struct('species', {'X2'}, 'stoichiometry', {1}), 'product', struct('species', {'X3'}, 'stoichiometry', {1}), 'reversible', false);
model.reaction(4) = struct('id', 'X1+X2->X1+X4', 'reactant', struct('species', {'X1', 'X2'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'X1', 'X4'}, 'stoichiometry', {1, 1}), 'reversible', false);
model.reaction(5) = struct('id', 'X3->0', 'reactant', struct('species', {'X3'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);
model.reaction(6) = struct('id', 'X4->0', 'reactant', struct('species', {'X4'}, 'stoichiometry', {1}), 'product', struct('species', { }, 'stoichiometry', { }), 'reversible', false);

% Generate the independent decomposition
[model, R, G, P] = indep_decomp(model);