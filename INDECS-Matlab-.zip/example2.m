% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 2                                                              %
%                                                                           %
%                                                                           %
% This is Example 9 in Hernandez and De la Cruz (2021): A metabolic network %
%    with one positive feedforward and a negative feedback                  %
%                                                                           %
% RESULT: The network of 6 reactions has no nontrivial independent          %
%    decomposition.                                                         %
%                                                                           %
% Reference: Hernandez B, De la Cruz R (2021) Independent decompositions of %
%    chemical reaction networks. Bull Math Biol 83(76):1–23.                %
%    https://doi.org/10.1007/s11538-021-00906-3                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 2';
model = addReaction(model, '0->X1', ...          % just a visual guide on how the reaction looks like
                           { }, { }, [ ], ...    % reactant species, stoichiometry, kinetic order
                           {'X1'}, {1}, [ ], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           false);               % reversible or not
model = addReaction(model, 'X1+X3->X3+X2', ...
                           {'X1', 'X3'}, {1, 1}, [1, 1], ...
                           {'X3', 'X2'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'X2->X3', ...
                           {'X2'}, {1}, [1], ...
                           {'X3'}, {1}, [ ], ...
                           false);
model = addReaction(model, 'X1+X2->X1+X4', ...
                           {'X1', 'X2'}, {1, 1}, [1, 1], ...
                           {'X1', 'X4'}, {1, 1}, [ ], ...
                           false);
model = addReaction(model, 'X3->0', ...
                           {'X3'}, {1}, [1], ...
                           {}, {}, [ ], ...
                           false);
model = addReaction(model, 'X4->0', ...
                           {'X4'}, {1}, [1], ...
                           {}, {}, [ ], ...
                           false);

% Generate the independent decomposition
[model, R, G, P] = indepDecomp(model);